# mock bundle

A fixture archive. It exists so the client's archive listing has a real central directory to
read: four entries, two folders, and sizes that differ enough to tell the columns apart.

Nothing in here is executed. The files are plausible rather than meaningful.
