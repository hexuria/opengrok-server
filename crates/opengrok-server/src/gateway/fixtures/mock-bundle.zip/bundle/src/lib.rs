//! A second file in the same folder, so the listing has a folder with more than one child.

/// Sum a slice, the long way round, so there is something to look at.
pub fn total(values: &[i64]) -> i64 {
    let mut sum = 0;
    for value in values {
        sum += value;
    }
    sum
}

/// The largest value, or None for an empty slice.
pub fn largest(values: &[i64]) -> Option<i64> {
    values.iter().copied().max()
}
