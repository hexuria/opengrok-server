//! The entry point of a program that does not exist.

fn main() {
    let names = ["ada", "grace", "katherine"];
    for (index, name) in names.iter().enumerate() {
        println!("{index}: {name}");
    }
    println!("{}", greeting("world"));
}

/// Said once, at the end.
fn greeting(who: &str) -> String {
    format!("hello, {who}")
}

#[cfg(test)]
mod tests {
    use super::greeting;

    #[test]
    fn it_greets() {
        assert_eq!(greeting("world"), "hello, world");
    }
}
